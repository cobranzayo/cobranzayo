# carde
the best cvc - ccv - cvv checker working 10000%

# usage
```
sudo apt-get python3
pip install requests
git clone https://github.com/laganty/carde.git
cd carde
python3 carde.py

```
# ss
<br>
<img src="تعليق توضيحي 2020-10-23 213709.png"></img>
<br>

# Developer:
TELEGRAM: http://t.me/laganty  .&.  CHANNEL: http://t.me/L_DEVv

GMAIL: laganty@outlook.sa  .&.

FACEBOOK: http://fb.com/laganty.dev.3  .&.

INSTAGRAM: http://instagram.com/lagant.y  .&.
